Syndesis Brand logo assets
